# Loads the model & tokenizer
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

# lightweight test model
MODEL_NAME = "bigscience/bloom-560m"

def load_model():
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
    
    # Move model to GPU if available
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)

    return model, tokenizer, device

# Function to run the model
def generate_text(model, tokenizer, device, input_text):

    prompt = f"Translate the following sentence from English to French: '{input_text}'"

    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    outputs = model.generate(**inputs, max_length=50)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)
