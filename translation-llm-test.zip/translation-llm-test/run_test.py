# Main script to run LLM on test data
import json
from model_loader import load_model, generate_text

# Load Model
model, tokenizer, device = load_model()

# Load Test Data
with open("test_data.json", "r") as file:
    test_cases = json.load(file)

# Run LLM on Test Cases
for case in test_cases:
    input_text = case["input"]
    expected_output = case["expected_output"]

    generated_text = generate_text(model, tokenizer, device, input_text)

    print(f" Input: {input_text}")
    print(f" Generated: {generated_text}")
    print(f" Expected: {expected_output}\n")
