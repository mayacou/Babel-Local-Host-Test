# Computes BLEU Score
from sacrebleu import corpus_bleu
from model_loader import load_model, generate_text
import json

# Load Model
model, tokenizer, device = load_model()

# Load Test Data
with open("test_data.json", "r") as file:
    test_cases = json.load(file)

# Generate Translations
generated_outputs = [generate_text(model, tokenizer, device, case["input"]) for case in test_cases]
expected_outputs = [[case["expected_output"]] for case in test_cases]  # Nested list format

# Compute BLEU Score
bleu_score = corpus_bleu(generated_outputs, expected_outputs)
print(f" BLEU Score: {bleu_score.score}")
